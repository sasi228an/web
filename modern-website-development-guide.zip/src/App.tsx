import { FormEvent, useState } from "react";

export default function App() {
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setIsSubmitted(true);
    event.currentTarget.reset();
  };

  return (
    <div className="bg-slate-950 text-slate-100">
      <header className="fixed inset-x-0 top-0 z-40 border-b border-white/10 bg-slate-950/85 backdrop-blur-sm">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between px-5 py-3">
          <a href="#home" className="text-lg font-semibold tracking-wide text-white">
            NOVA
          </a>
          <nav className="flex items-center gap-5 text-sm text-slate-300">
            <a href="#home" className="nav-link">
              Главная
            </a>
            <a href="#about" className="nav-link">
              О проекте
            </a>
            <a href="#contacts" className="nav-link">
              Контакты
            </a>
          </nav>
        </div>
      </header>

      <main>
        <section
          id="home"
          className="hero-bg relative flex min-h-screen items-center border-b border-white/10 px-5 pt-32 pb-16"
        >
          <div className="hero-overlay" aria-hidden="true" />
          <div className="relative mx-auto w-full max-w-6xl animate-reveal space-y-6">
            <p className="text-sm tracking-[0.2em] text-cyan-300">NOVA DIGITAL STUDIO</p>
            <h1 className="max-w-3xl text-4xl leading-tight font-semibold text-white sm:text-5xl md:text-6xl">
              Создаем быстрые и стильные сайты, которые помогают бизнесу расти
            </h1>
            <p className="max-w-2xl text-base text-slate-200 sm:text-lg">
              Запускаем современные веб-проекты под ключ: от идеи и дизайна до
              готового адаптивного сайта с понятной структурой.
            </p>
            <div className="flex flex-wrap gap-3">
              <a href="#contacts" className="btn-primary">
                Оставить заявку
              </a>
              <a href="#about" className="btn-secondary">
                Подробнее
              </a>
            </div>
          </div>
        </section>

        <section id="about" className="border-b border-white/10 px-5 py-20">
          <div className="mx-auto grid w-full max-w-6xl gap-10 md:grid-cols-2 md:gap-14">
            <div className="animate-reveal [animation-delay:120ms]">
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">О проекте</h2>
              <p className="mt-4 max-w-xl text-slate-300">
                NOVA помогает малому и среднему бизнесу выходить в онлайн с
                современными и понятными сайтами. Мы фокусируемся на минимализме,
                скорости загрузки и удобстве для пользователя.
              </p>
            </div>

            <div className="animate-reveal space-y-4 [animation-delay:240ms]">
              <article>
                <h3 className="text-xl font-medium text-white">Что вы получаете</h3>
                <p className="mt-2 text-slate-300">
                  Продуманную структуру страниц, адаптивный интерфейс для мобильных
                  устройств и современный визуальный стиль без лишнего шума.
                </p>
              </article>
              <article>
                <h3 className="text-xl font-medium text-white">Для кого</h3>
                <p className="mt-2 text-slate-300">
                  Для стартапов, экспертов и локального бизнеса, которым нужен
                  профессиональный сайт для презентации услуг и получения заявок.
                </p>
              </article>
            </div>
          </div>
        </section>

        <section id="contacts" className="px-5 py-20">
          <div className="mx-auto grid w-full max-w-6xl gap-10 md:grid-cols-2 md:gap-14">
            <div className="animate-reveal [animation-delay:120ms]">
              <h2 className="text-3xl font-semibold text-white sm:text-4xl">Контакты</h2>
              <p className="mt-4 max-w-xl text-slate-300">
                Расскажите о вашей задаче через форму. Мы ответим на email и
                предложим оптимальный формат запуска проекта.
              </p>
              <p className="mt-6 text-sm text-slate-400">Email: hello@nova-site.dev</p>
              <p className="text-sm text-slate-400">Телефон: +7 (900) 123-45-67</p>
            </div>

            <form
              onSubmit={handleSubmit}
              className="animate-reveal space-y-4 rounded-2xl border border-white/15 bg-white/5 p-6 [animation-delay:240ms]"
            >
              <label className="block text-sm text-slate-200" htmlFor="name">
                Имя
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                placeholder="Как к вам обращаться"
                className="input"
              />

              <label className="block text-sm text-slate-200" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                placeholder="you@example.com"
                className="input"
              />

              <label className="block text-sm text-slate-200" htmlFor="message">
                Сообщение
              </label>
              <textarea
                id="message"
                name="message"
                required
                rows={4}
                placeholder="Коротко опишите задачу"
                className="input min-h-28"
              />

              <button type="submit" className="btn-primary w-full justify-center">
                Отправить
              </button>

              {isSubmitted ? (
                <p className="text-sm text-emerald-300">
                  Спасибо. Форма отправлена, мы свяжемся с вами в ближайшее время.
                </p>
              ) : null}
            </form>
          </div>
        </section>
      </main>

      <footer className="border-t border-white/10 px-5 py-6 text-center text-sm text-slate-400">
        {new Date().getFullYear()} NOVA Digital Studio. Все права защищены.
      </footer>
    </div>
  );
}
